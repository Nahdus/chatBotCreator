from rest_framework import serializers
from edit_bot.models import Flow,Bot

class FlowSerializers(serializers.ModelSerializer):
    words = serializers.StringRelatedField(many=True)
    bot = serializers.StringRelatedField(many=False)
    
    class Meta:
        model = Flow
        fields = ('bot','order','Question','Answers','words')

class BotSerializers(serializers.ModelSerializer):
    # bot = serializers.StringRelatedField(many=False)
    class Meta:
        model = Bot
        fields = ('Name','id')