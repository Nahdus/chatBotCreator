from django.shortcuts import render
from rest_framework import generics
from edit_bot.models import Flow
from .serializers import FlowSerializers,BotSerializers
from dashboard.models import Bot
from rest_framework.response import Response


class FlowViewList(generics.ListCreateAPIView):
    queryset = Flow.objects.all()
    serializer_class = FlowSerializers


class BotFlowViewList(generics.ListCreateAPIView):
    
    
    serializer_class = FlowSerializers

    def get_queryset(self):
        return Flow.objects.filter(bot=Bot.objects.get(id=self.botId))

    def list(self, request,bot_id):
        self.botId=bot_id
        # Note the use of `get_queryset()` instead of `self.queryset`
        queryset=self.get_queryset()
        print(queryset[0].bot)
        serializer = self.serializer_class(queryset, many=True)
        #print(serializer.data)
        #print(dir(serializer.data[0]['words']))
        return Response(serializer.data)


class Botlist(generics.ListCreateAPIView):
    queryset = Bot.objects.all()
    serializer_class = BotSerializers
