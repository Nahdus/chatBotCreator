from django.apps import AppConfig


class ApigateConfig(AppConfig):
    name = 'apigate'
