from django.apps import AppConfig


class EditBotConfig(AppConfig):
    name = 'edit_bot'
